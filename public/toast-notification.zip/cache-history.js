// cache-history.js - 缓存历史页面脚本

import i18n from '../i18n/i18n.js';

console.log('[CacheHistory] 页面加载');

// DOM 元素
const cacheList = document.getElementById('cacheList');
const emptyState = document.getElementById('emptyState');
const loadingIndicator = document.getElementById('loadingIndicator');
const statusMessage = document.getElementById('statusMessage');
const refreshBtn = document.getElementById('refreshBtn');
const clearBtn = document.getElementById('clearBtn');
const totalCacheCount = document.getElementById('totalCacheCount');
const recentCount = document.getElementById('recentCount');
const maxCache = document.getElementById('maxCache');

/**
 * 翻译所有带有 data-i18n 属性的 DOM 元素
 */
function translatePage() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
        const key = el.getAttribute('data-i18n');
        const translation = i18n.t(key);
        el.textContent = translation;
    });
}

// 事件监听
refreshBtn.addEventListener('click', loadCacheHistory);
clearBtn.addEventListener('click', clearCache);

// 页面加载时获取缓存并初始化 i18n
document.addEventListener('DOMContentLoaded', async () => {
    console.log('[CacheHistory] DOM 加载完成');
    
    // 初始化 i18n
    await i18n.load('cache');  // 只加載 cache 模組
    translatePage();
    
    // 监听语言变化
    i18n.onLanguageChange(() => {
        console.log('[CacheHistory] 语言已变更，重新翻译页面');
        translatePage();
        // 重新渲染缓存列表以应用新语言的动态内容（时间格式、过期状态等）
        loadCacheHistory();
    });
    
    console.log('[CacheHistory] 获取缓存历史');
    loadCacheHistory();
});

/**
 * 从 Service Worker 获取缓存统计数据
 */
async function loadCacheHistory() {
    try {
        showLoading(true);
        clearStatus();
        
        console.log('[CacheHistory] 请求缓存统计数据');
        
        // 发送消息给 Service Worker
        const response = await chrome.runtime.sendMessage({
            action: 'get_cache_stats'
        });
        
        console.log('[CacheHistory] 收到响应:', response);
        
        if (response && response.status === 'success') {
            const stats = response.data;
            
            // 更新统计卡片
            updateStats(stats);
            
            // 更新缓存列表
            if (stats.recentEntries && stats.recentEntries.length > 0) {
                renderCacheList(stats.recentEntries);
                emptyState.style.display = 'none';
            } else {
                cacheList.innerHTML = '';
                emptyState.style.display = 'block';
            }
            
            showStatus(i18n.t('cache.msg.updated'), 'success');
        } else {
            showStatus(i18n.t('cache.msg.error') + ': ' + (response?.error || '未知错误'), 'error');
        }
    } catch (error) {
        console.error('[CacheHistory] 错误:', error);
        showStatus('❌ 错误: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

/**
 * 更新统计卡片
 */
function updateStats(stats) {
    totalCacheCount.textContent = stats.totalCacheSize || 0;
    recentCount.textContent = stats.recentCount || 0;
    maxCache.textContent = stats.maxCacheSize || 50;  // 改為顯示 maxCacheSize（50）
    
    // 🆕 Phase 4：顯示過期快取統計
    const expiredCountEl = document.getElementById('expiredCount');
    const validCountEl = document.getElementById('validCount');
    
    if (expiredCountEl && stats.expiredCount !== undefined) {
        expiredCountEl.textContent = stats.expiredCount;
    }
    
    if (validCountEl && stats.validCount !== undefined) {
        validCountEl.textContent = stats.validCount;
    }
    
    // 更新存儲使用信息
    if (stats.storage) {
        const storage = stats.storage;
        const progressBar = document.getElementById('storageProgressBar');
        const progressText = document.getElementById('storageText');
        const usedSizeEl = document.getElementById('usedSize');
        const percentageEl = document.getElementById('percentage');
        
        if (progressBar) {
            progressBar.style.width = storage.percentage + '%';
            // 根據狀態改變顏色
            progressBar.className = 'progress-bar';
            if (storage.status === 'warning') {
                progressBar.classList.add('warning');
            } else if (storage.status === 'critical') {
                progressBar.classList.add('critical');
            }
        }
        
        if (progressText) {
            progressText.textContent = storage.percentage + '%';
        }
        
        if (usedSizeEl) {
            // 改為顯示 "N / 50" 的格式（項目數）
            usedSizeEl.textContent = storage.used + ' / ' + storage.max;
        }
        
        if (percentageEl) {
            percentageEl.textContent = storage.percentage + '%';
            percentageEl.className = 'percentage-badge';
            if (storage.status === 'warning') {
                percentageEl.classList.add('warning');
            } else if (storage.status === 'critical') {
                percentageEl.classList.add('critical');
            }
        }
    }
}

/**
 * 渲染缓存列表
 */
function renderCacheList(entries) {
    cacheList.innerHTML = '';
    
    entries.forEach((entry, index) => {
        const li = document.createElement('li');
        li.className = 'cache-item';
        
        // 格式化时间戳
        const timeStr = formatTime(entry.timestamp);
        
        // 🆕 Phase 4：計算過期倒計時（還剩多少天）
        let expiryInfo = '';
        if (entry.expiresAt) {
            const now = Date.now();
            const daysRemaining = Math.ceil((entry.expiresAt - now) / (24 * 60 * 60 * 1000));
            
            if (daysRemaining <= 0) {
                expiryInfo = `<span class="expiry-expired">${i18n.t('cache.expiry.expired')}</span>`;
            } else if (daysRemaining <= 7) {
                expiryInfo = `<span class="expiry-warning">⚠️ ${i18n.t('cache.expiry.expiringIn').replace('{days}', daysRemaining)}</span>`;
            } else if (daysRemaining <= 14) {
                expiryInfo = `<span class="expiry-info">ℹ️ ${i18n.t('cache.expiry.expiringIn').replace('{days}', daysRemaining)}</span>`;
            } else {
                expiryInfo = `<span class="expiry-valid">${i18n.t('cache.expiry.valid').replace('{days}', daysRemaining)}</span>`;
            }
        }
        
        // 格式化 args 为可读文本
        const argsStr = JSON.stringify(entry.args, null, 2).substring(0, 200);
        
        li.innerHTML = `
            <div class="cache-item-header">
                <div class="cache-item-input-container">
                    <div class="cache-item-input">
                        #${index + 1} "${entry.userInput}"
                    </div>
                </div>
                <button class="cache-item-delete-btn" title="${i18n.t('cache.list.deleteItem')}">🗑️</button>
            </div>
            <div class="cache-item-details">
                <div class="detail-row">
                    <span class="detail-label">${i18n.t('cache.list.skill')}</span>
                    <span class="detail-value">${escapeHtml(entry.skill)}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">${i18n.t('cache.list.params')}</span>
                    <span class="detail-value"><code>${escapeHtml(argsStr)}</code></span>
                </div>
            </div>
            <div class="cache-item-time">
                ⏱️ ${timeStr}
            </div>
            <div class="cache-item-expiry">
                ${expiryInfo}
            </div>
        `;
        
        cacheList.appendChild(li);
        
        // 为删除按钮添加事件监听
        const deleteBtn = li.querySelector('.cache-item-delete-btn');
        deleteBtn.addEventListener('click', () => {
            deleteSpecificCache(entry.userInput, li);
        });
    });
}

/**
 * 格式化时间戳
 */
function formatTime(timestamp) {
    if (!timestamp) return i18n.t('cache.time.unknown');
    
    const now = Date.now();
    const diff = now - timestamp;
    
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} ${i18n.t('cache.time.daysAgo')}`;
    if (hours > 0) return `${hours} ${i18n.t('cache.time.hoursAgo')}`;
    if (minutes > 0) return `${minutes} ${i18n.t('cache.time.minutesAgo')}`;
    if (seconds > 0) return `${seconds} ${i18n.t('cache.time.secondsAgo')}`;
    return i18n.t('cache.time.justNow');
}

/**
 * 删除指定的单条缓存
 */
async function deleteSpecificCache(userInput, element) {
    const confirmMsg = i18n.t('cache.msg.deleteConfirm') + `"${userInput}"`;
    if (!confirm(confirmMsg)) {
        return;
    }
    
    try {
        console.log('[CacheHistory] 请求删除指定缓存:', userInput);
        
        const response = await chrome.runtime.sendMessage({
            action: 'delete_cache_item',
            userInput: userInput
        });
        
        if (response && response.status === 'success') {
            // 删除 UI 中的该项
            element.style.opacity = '0';
            element.style.transform = 'translateX(-20px)';
            
            setTimeout(() => {
                element.remove();
                
                // 如果列表为空，显示空状态
                if (cacheList.children.length === 0) {
                    emptyState.style.display = 'block';
                }
                
                showStatus(i18n.t('cache.msg.deleted') + userInput, 'success');
                
                // 执行完整的刷新流程（类似点击刷新按钮）
                setTimeout(() => {
                    loadCacheHistory();
                }, 500);
            }, 300);
        } else {
            showStatus(i18n.t('cache.msg.deleteFailed'), 'error');
        }
    } catch (error) {
        console.error('[CacheHistory] 删除错误:', error);
        showStatus('❌ 错误: ' + error.message, 'error');
    }
}

/**
 * 清空缓存
 */
async function clearCache() {
    if (!confirm(i18n.t('cache.msg.clearConfirm'))) {
        return;
    }
    
    try {
        showLoading(true);
        clearStatus();
        
        console.log('[CacheHistory] 请求清空缓存');
        
        const response = await chrome.runtime.sendMessage({
            action: 'clear_cache'
        });
        
        if (response && response.status === 'success') {
            cacheList.innerHTML = '';
            emptyState.style.display = 'block';
            updateStats({ totalCacheSize: 0, recentCount: 0, maxRecent: 10 });
            showStatus(i18n.t('cache.msg.cleared'), 'success');
        } else {
            showStatus(i18n.t('cache.msg.clearFailed'), 'error');
        }
    } catch (error) {
        console.error('[CacheHistory] 清空错误:', error);
        showStatus('❌ 错误: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

/**
 * 显示或隐藏加载指示器
 */
function showLoading(show) {
    loadingIndicator.style.display = show ? 'block' : 'none';
}

/**
 * 显示状态消息
 */
function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
    statusMessage.style.display = 'block';
    
    // 3 秒后自动隐藏成功消息
    if (type === 'success') {
        setTimeout(() => {
            statusMessage.style.display = 'none';
        }, 3000);
    }
}

/**
 * 清除状态消息
 */
function clearStatus() {
    statusMessage.style.display = 'none';
    statusMessage.className = 'status-message';
}

/**
 * HTML 转义函数
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}
